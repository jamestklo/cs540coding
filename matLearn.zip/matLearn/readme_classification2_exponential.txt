Lo, Teng Kin
46867024
tklo@cs.ubc.ca

CPSC 540 Machine Learning 2014W
UBC Computer Science


A. Value-added Contributions

1) addBias: add a bias column to design matrix
In addition to implementing matLearn_ordinal_regression.m,  I fixed the model.addBias bug in matLearn_classification2_exponential.m
The original code would make model.addBias = 1, even when user set options.addBias = 0


B. Collaboration
Please see readme_ordinal_regression.txt


C. Setup
Please see readme_ordinal_regression.txt
