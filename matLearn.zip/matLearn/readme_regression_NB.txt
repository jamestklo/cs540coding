Scott Sallinen
47778105
scotts@ece.ubc.ca

CPSC 540 Machine Learning 2014W
UBC Computer Science


A. Value-added Contributions

1) weights: give weights to training samples

2) lambdaL2: add a L2 regularization term options.lambdaL2

3) addBias: add a bias column to design matrix


B. Collaboration
please see readme_regression_refactoredL2NB.txt


C. Setup
The code assumes all the files are inside the folder ./matLearn

1) matLearn_regression_NB.m
implements the regression_NB model

2) demo_regression_NB.m
demo of regression_NB model

3)linearRegressionData.mat
data used in demo

4)minFunc_2012/
we need to call minFunc_2012/minFunc
