You should be able to run the following demos:
- demo_regressOnOne (1D regression demo)
- demo_exponential (2D classification demo)

The second demo assumes that the 'minFunc_2012' directory is on the path. To add it to the path from the matLearn directory, type:
>> addpath minFunc_2012

Note that this basic package might be updated as we get closer to the deadline. 
For example, if people suggest common functions that should be acceptable across the packages or if people finish early.
